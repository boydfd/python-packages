``tornado.platform.twisted`` --- Bridges between Twisted and Tornado
========================================================================

.. automodule:: tornado.platform.twisted

   Twisted DNS resolver
   --------------------

   .. autoclass:: TwistedResolver
      :members:
